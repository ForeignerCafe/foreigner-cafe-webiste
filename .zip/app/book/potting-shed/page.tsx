import React from "react";

const page = () => {
  return <div className="p-56">page</div>;
};

export default page;
